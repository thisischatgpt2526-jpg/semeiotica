# MedQuiz – versione gratuita per GitHub Pages

Questa è una versione autonoma HTML di MedQuiz, non l’esportazione identica del progetto Lovable.

## Pubblicazione
1. Apri il repository `semeiotica` su GitHub.
2. Seleziona **Add file > Upload files** e carica **index.html** e **.nojekyll** (estratti dallo ZIP).
3. Premi **Commit changes**.
4. Vai in **Settings > Pages**. In **Build and deployment**, scegli **Deploy from a branch**, branch **main**, cartella **/(root)**, quindi **Save**.
5. Il sito sarà disponibile all’indirizzo `https://thisischatgpt2526-jpg.github.io/semeiotica/` dopo la pubblicazione.

I progressi sono salvati nel browser/dispositivo, non sincronizzati tra dispositivi. Le domande ufficiali del PDF non sono ancora state importate.
